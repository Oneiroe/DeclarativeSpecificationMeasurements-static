import sys
import os

def main(declare_model, perracotta_model_appro, perracotta_models_strict):
    first=True
    with open(perracotta_model_appro,'r') as in_file, open(declare_model,'w') as output_file:
        output_file.write('{"name": "Process model","constraints": [\n')
        for model in perracotta_models_strict:
            if model.endswith("appro") or model.endswith("Events"):
                continue
            with open(model,'r') as fix_file:
                for line in fix_file:
                    head,var1,arrow,var2,end=line.split('"')
                    var1=var1.split('.')[0]
                    var2=var2.split('.')[0]
                    if not first:
                        output_file.write(",\n")
                    else:
                        first=False
                    if model.endswith("al"):
                        out='{"template": "AlternateResponse","parameters": [["'+var1+'"],["'+var2+'"]],"support": 1.0,"confidence": 1.0,"interestFactor": 1.0}'
                        output_file.write(f"{out}")
                    else:
                        out='{"template": "Response","parameters": [["'+var1+'"],["'+var2+'"]],"support": 1.0,"confidence": 1.0,"interestFactor": 1.0}'
                        output_file.write(f"{out}")



        for line in in_file:
            if line.startswith("pAL"):
                continue
            if not first:
                output_file.write(",\n")
            else:
                first=False
            support,var1,arrow,var2,end=line.split('"')
            var1=var1.split('.')[0]
            var2=var2.split('.')[0]
            out='{"template": "AlternateResponse","parameters": [["'+var1+'"],["'+var2+'"]],"support": '+support+',"confidence": '+support+',"interestFactor": 1.0}'
            output_file.write(f"{out}")


        output_file.write('\n]}')

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], sys.argv[3:])
