from pm4py.objects.log.importer.xes import importer as xes_importer
from pm4py.objects.conversion.log import converter as log_converter
import pandas as pd
import csv
import sys

def main(xes_log, csv_log, perracotta_log):
    log = xes_importer.apply(xes_log)
    dataframe = log_converter.apply(log, variant=log_converter.Variants.TO_DATA_FRAME)
    dataframe.to_csv(csv_log)

    last_case="case:concept:name"

    with open(csv_log,'r') as csv_file, open(perracotta_log,'w') as output_file:
        csv_reader=csv.DictReader(csv_file)
        for line in csv_reader:
            if line["concept:name"] =="concept:name":
                continue
            event = line["concept:name"]
            if line["case:concept:name"]!=last_case:
                output_file.write("----\n")
                last_case=line["case:concept:name"]
            else:
                output_file.write(f"Enter: {event}.execute()\n")
                output_file.write(f"Exit: {event}.execute()\n")

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], sys.argv[3])


